import React from "react";
import "./App.css";
import { AnimatePresence, motion } from "framer-motion";
import Footer from "./Components/Footer";
import NavBar from "./Components/NavBar";
import HomePage from "./Components/HomePage";
import HomeNews from "./Components/HomeNews";
import AidePage from "./Components/AidePage";
import ContactPage from "./Components/ContactPage";
import { BrowserRouter as Router, Route, Switch, useLocation } from 'react-router-dom';

function App() {
  return (
    <div className="flex flex-col min-h-screen">
      <Router>
        <NavBar />
        <div className="flex-grow">
          <PageTransition />
        </div>
        <Footer />
      </Router>
    </div>
  );
}

function PageTransition() {
  const location = useLocation();

  return (
    <AnimatePresence mode="wait">
      <Switch location={location} key={location.key}>
        <Route path="/contact" component={ContactPage} />
        <Route path="/aide" component={AidePage} />
        <Route exact path="/">
          <motion.div initial={{ opacity: 0.8 }} animate={{ opacity: 1 }} exit={{ opacity: 0.8 }} transition={{ duration: 0.2, ease: "linear"  }} >
            <HomePage />
            <HomeNews />
          </motion.div>
        </Route>
      </Switch>
    </AnimatePresence>
  );
}

export default App;