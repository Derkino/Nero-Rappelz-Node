import React from "react";

import "./css/Home_Rank.css";
import "./css/General_Utils.css";
import { Link } from "react-router-dom";

const HomeRank = () => {
  return (
    <div className="Rank_Container flex items-center justify-center"  style={{ backgroundImage: `url(${process.env.PUBLIC_URL + "/Assets/Images/dragon.jpg"})` }}>
      <div className="flex w-full">

        <div className="w-1/2 flex items-center justify-center">
          <div style={{ width: '80%' }}>
            <div class="container">
              <table class="w-full block rounded-lg overflow-hidden sm:shadow-lg my-5">

                <tbody class="block w-full">
                <h2 className="Rank_Txt text-center">Classement par Niveau</h2>
                  <tr className="table_color">
                    <td class="p-3" style={{ width: '10%' }}>Classe</td>
                    <td class="p-3" style={{ width: '55%' }}>Nom</td>
                    <td class="p-3" style={{ width: '10%' }}>Niveau</td>
                    <td class="p-3" style={{ width: '25%' }}>PK Count</td>
                  </tr>
                  <tr className="table_color table_color_hover">
                  <td class="p-3" style={{ width: '10%' }}><img className="w-full" alt="Job" src="Assets/Images/1.jpg" /></td>
                    <td class="p-3" style={{ width: '55%' }}>Hiro</td>
                    <td class="p-3" style={{ width: '10%' }}>160</td>
                    <td class="p-3" style={{ width: '25%' }}>10</td>
                  </tr>
                  <tr className="table_color table_color_hover">
                  <td class="p-3" style={{ width: '10%' }}><img className="w-full" alt="Job" src="Assets/Images/2.jpg" /></td>
                    <td class="p-3" style={{ width: '55%' }}>Aeklys</td>
                    <td class="p-3" style={{ width: '10%' }}>160</td>
                    <td class="p-3" style={{ width: '25%' }}>10</td>
                  </tr>
                  <tr className="table_color table_color_hover">
                  <td class="p-3" style={{ width: '10%' }}><img className="w-full" alt="Job" src="Assets/Images/3.jpg" /></td>
                    <td class="p-3" style={{ width: '55%' }}>AelenAkola</td>
                    <td class="p-3" style={{ width: '10%' }}>160</td>
                    <td class="p-3" style={{ width: '25%' }}>10</td>
                  </tr>
                  <tr className="table_color table_color_hover">
                  <td class="p-3" style={{ width: '10%' }}><img className="w-full" alt="Job" src="Assets/Images/4.jpg" /></td>
                    <td class="p-3" style={{ width: '55%' }}>Luciaaa</td>
                    <td class="p-3" style={{ width: '10%' }}>160</td>
                    <td class="p-3" style={{ width: '25%' }}>10</td>
                  </tr>
                  <tr className="table_color table_color_hover">
                  <td class="p-3" style={{ width: '10%' }}><img className="w-full" alt="Job" src="Assets/Images/5.jpg" /></td>
                    <td class="p-3" style={{ width: '55%' }}>Croissant</td>
                    <td class="p-3" style={{ width: '10%' }}>160</td>
                    <td class="p-3" style={{ width: '25%' }}>10</td>
                  </tr>
                  <div className="btndiv">
                  <Link to="/Rank/Level" className="Button_Rank rankbtn">Voir le classement</Link>
                  </div>
                </tbody>
              </table>
            </div>
          </div>

        </div>
        <div className="w-1/2 flex items-center justify-center">
          <div style={{ width: '80%' }}>
            <div class="container">
              <table class="w-full block rounded-lg overflow-hidden sm:shadow-lg my-5">

              <tbody class="block w-full">
                <h2 className="Rank_Txt text-center">Classement par PK</h2>
                  <tr className="table_color">
                    <td class="p-3" style={{ width: '10%' }}>Classe</td>
                    <td class="p-3" style={{ width: '55%' }}>Nom</td>
                    <td class="p-3" style={{ width: '10%' }}>Niveau</td>
                    <td class="p-3" style={{ width: '25%' }}>PK Count</td>
                  </tr>
                  <tr className="table_color table_color_hover">
                  <td class="p-3" style={{ width: '10%' }}><img className="w-full" alt="Job" src="Assets/Images/1.jpg" /></td>
                    <td class="p-3" style={{ width: '55%' }}>Hiro</td>
                    <td class="p-3" style={{ width: '10%' }}>160</td>
                    <td class="p-3" style={{ width: '25%' }}>10</td>
                  </tr>
                  <tr className="table_color table_color_hover">
                  <td class="p-3" style={{ width: '10%' }}><img className="w-full" alt="Job" src="Assets/Images/2.jpg" /></td>
                    <td class="p-3" style={{ width: '55%' }}>Aeklys</td>
                    <td class="p-3" style={{ width: '10%' }}>160</td>
                    <td class="p-3" style={{ width: '25%' }}>10</td>
                  </tr>
                  <tr className="table_color table_color_hover">
                  <td class="p-3" style={{ width: '10%' }}><img className="w-full" alt="Job" src="Assets/Images/3.jpg" /></td>
                    <td class="p-3" style={{ width: '55%' }}>AelenAkola</td>
                    <td class="p-3" style={{ width: '10%' }}>160</td>
                    <td class="p-3" style={{ width: '25%' }}>10</td>
                  </tr>
                  <tr className="table_color table_color_hover">
                  <td class="p-3" style={{ width: '10%' }}><img className="w-full" alt="Job" src="Assets/Images/4.jpg" /></td>
                    <td class="p-3" style={{ width: '55%' }}>Luciaaa</td>
                    <td class="p-3" style={{ width: '10%' }}>160</td>
                    <td class="p-3" style={{ width: '25%' }}>10</td>
                  </tr>
                  <tr className="table_color table_color_hover">
                  <td class="p-3" style={{ width: '10%' }}><img className="w-full" alt="Job" src="Assets/Images/5.jpg" /></td>
                    <td class="p-3" style={{ width: '55%' }}>Croissant</td>
                    <td class="p-3" style={{ width: '10%' }}>160</td>
                    <td class="p-3" style={{ width: '25%' }}>10</td>
                  </tr>
                  <div className="btndiv">
                  <Link to="/Rank/Pk" className="Button_Rank rankbtn">Voir le classement</Link>
                  </div>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomeRank;