// Importe React et les styles de Tailwind CSS
import React from "react";
import { Link } from 'react-router-dom';
import "./css/Footer.css";

// fonction flêchée qui retourne le footer

const Footer = () => {
    return (
        <footer className="bg-gray-800 p-10 text-white flex justify-center items-center">
            <Link to="/about" className="Footer-btn">About</Link>
            <Link to="/download" className="Footer-btn">Download</Link>
            <Link to="/aide" className="Footer-btn">Aide</Link>
        </footer>
    );
};

export default Footer;
// Exporte la fonction Footer
