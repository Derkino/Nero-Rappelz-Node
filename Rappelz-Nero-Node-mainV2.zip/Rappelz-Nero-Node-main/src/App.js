import React from "react";
import "./App.css";
import { AnimatePresence, motion } from "framer-motion";
import { animationProps } from './Components/utils/animationProps';
import Footer from "./Components/utils/Footer";
import NavBar from "./Components/utils/NavBar";
import HomePage from "./Components/pages/HomePage";
import HomeNews from "./Components/pages/HomeNews";
import AnnoncePage from "./Components/pages/AnnoncePage";
import AidePage from "./Components/pages/AidePage";
import ContactPage from "./Components/pages/ContactPage";
import { BrowserRouter as Router, Route, Switch, useLocation } from 'react-router-dom';

function App() {
  return (
    <div className="flex flex-col min-h-screen">
      <Router>
        <NavBar />
        <MainPage />
        <Footer />
      </Router>
    </div>
  );
}

function MainPage() {
  const location = useLocation();

  return (
    <div className="flex-grow">
      <Switch location={location} key={location.key}>
        <Route path="/contact" component={ContactPage} />
        <Route path="/aide" component={AidePage} />
        <Route path="/annonce" component={AnnoncePage} />
        <Route exact path="/">
          <AnimatePresence mode="wait">
          <motion.div {...animationProps}>
              <HomePage />
              <HomeNews />
            </motion.div>
          </AnimatePresence>
        </Route>
      </Switch>
    </div>
  );
}

export default App;