import React from "react";

import "../css/Home_News.css";
import Card from '../utils/newCards';
import "../css/HomePage.css";
import "../css/General_Utils.css";

const AnnoncePage = () => {
    return (
        <div>
            <div className="News_Container">
                <h2 className="News_Title">Dernières mises à jour</h2>
                <div className="card-container">

                    <Card
                        image="mephisto.jpg"
                        altText="Sunset in the mountains"
                        title="The Coldest Sunset"
                        text="Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus quia, nulla! Maiores et perferendis eaque, exercitationem praesentium nihil."
                        buttonText="Voir la mise à jour"
                    />

                    <Card
                        image="mephisto.jpg"
                        altText="Sunset in the mountains"
                        title="The Coldest Sunset"
                        text="Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus quia, nulla! Maiores et perferendis eaque, exercitationem praesentium nihil."
                        buttonText="Voir la mise à jour"
                    />

                    <Card
                        image="mephisto.jpg"
                        altText="Sunset in the mountains"
                        title="The Coldest Sunset"
                        text="Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus quia, nulla! Maiores et perferendis eaque, exercitationem praesentium nihil."
                        buttonText="Voir la mise à jour"
                    />
                </div>
            </div>
            <div className="flex justify-center items-center">
                <button className="text-center">Voir toutes les mises à jour</button>
            </div>
        </div>
    );
};

export default AnnoncePage;
