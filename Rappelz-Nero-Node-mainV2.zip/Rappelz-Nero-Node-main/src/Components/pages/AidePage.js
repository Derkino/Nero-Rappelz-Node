import React from "react";
import "../css/Contact_Page.css";
import "../css/General_Utils.css";
import { motion } from "framer-motion";
import { animationProps } from "../utils/animationProps";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faYoutube, faGithub, faDiscord } from '@fortawesome/free-brands-svg-icons';

const AidePage = () => {
    return (
        <motion.div {...animationProps}>
        <div className="mx-auto contact-fade overflow-x-hidden" style={{ 
            backgroundImage: `linear-gradient(to bottom, rgba(255,255,255,0) 0%, rgba(255,255,255,1) 100%), url(${'/Assets/Images/Help.jpeg'})`, 
            backgroundRepeat: 'no-repeat', 
            backgroundSize: 'cover' 
        }}>
            <h1 className="text-center Contact_Font_H1">Besoin d'aide ?</h1>
            <p className="text-center mt-4">
                Vous avez un problème avec le jeu nécéssitant une action rapide ? <br/><br/> Contactez nous a l'adresse suivante : urgence@test.com <br/><br/>Vous pouvez également nous contacter en message privé sur Discord <br/><br/>Vous retrouverez sur ces liens de quoi répondre à vos questions, si vous ne trouvez pas la réponse, contactez nous.
            </p><br />
            <div className="flex justify-center">
                <a href="https://youtube.com"><FontAwesomeIcon className="Icon-Class" icon={faYoutube} /> </a>
                <a href="https://github.com"><FontAwesomeIcon className="Icon-Class" icon={faGithub} /> </a>
                <a href="https://discord.com"><FontAwesomeIcon className="Icon-Class" icon={faDiscord} /> </a>
            </div>
        </div>
        </motion.div>
    );
};

export default AidePage;