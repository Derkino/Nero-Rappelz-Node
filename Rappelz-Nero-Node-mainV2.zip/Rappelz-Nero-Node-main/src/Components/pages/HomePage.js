import React from 'react';
import { Link } from 'react-router-dom';

const HomePage = () => {
    return (
        <div className="video-container">
            <video className="background-video" autoPlay loop muted playsInline>
            <source src={process.env.PUBLIC_URL + "/Video.mp4"} type="video/mp4" />
            </video>
            <div className="overlay">
            <marquee className="Rappelz_Information">Rappelz Nero n'est pas affilié a Gala © | Serveur [ON] | Votez pour le serveur pour gagner des récompenses</marquee>
            </div>
            <div className="content">
                <h1 className="Rappelz_Title">Rappelz Nero</h1>
                <p className="Rappelz_Subtitle">Découvrez notre expérience de jeu</p>
                <Link to="download" className="download-button download">Jouer Maintenant</Link>
            </div>
        </div>
    );
}

export default HomePage;