import React from "react";
import { motion } from "framer-motion";
import "../css/Contact_Page.css";
import "../css/General_Utils.css";
import { animationProps } from "../utils/animationProps";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faYoutube, faGithub, faDiscord } from '@fortawesome/free-brands-svg-icons';

const ContactPage = () => {
    return (
        <motion.div {...animationProps}>
        <div className="mx-auto contact-fade overflow-x-hidden" style={{ 
            backgroundImage: `linear-gradient(to bottom, rgba(255,255,255,0) 0%, rgba(255,255,255,1) 100%), url(${'/Assets/Images/test.jpg'})`, 
            backgroundRepeat: 'no-repeat', 
            backgroundSize: 'cover' 
        }}>
            <h1 className="text-center Contact_Font_H1">Comment nous contacter ?</h1>
            <p className="text-center mt-4">
                Pour nous contacter, vous avez plusieurs options.<br /><br /> Vous pouvez nous rejoindre sur notre serveur Discord : <br />Vous pouvez également nous envoyer un email à <a href="mailto:test@test.com">test@test.com</a>. <br /><br />Nous nous efforçons de répondre dans les plus brefs délais. Nous avons hâte de vous entendre !
            </p><br />
            <div className="flex justify-center">
                <a href="https://youtube.com"><FontAwesomeIcon className="Icon-Class" icon={faYoutube} /> </a>
                <a href="https://github.com"><FontAwesomeIcon className="Icon-Class" icon={faGithub} /> </a>
                <a href="https://discord.com"><FontAwesomeIcon className="Icon-Class" icon={faDiscord} /> </a>
            </div>
        </div>
        </motion.div>
    );
};

export default ContactPage;