export const animationProps = {
    initial: { opacity: 0, transition: { duration: 0.8 } },
    animate: { opacity: 1, transition: { duration: 0.8 } },
    exit: { opacity: 1, transition: { duration: 0.8 } }
};
