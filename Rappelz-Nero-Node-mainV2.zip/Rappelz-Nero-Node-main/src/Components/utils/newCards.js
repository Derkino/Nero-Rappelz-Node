function NewsCard({ image, altText, title, text, buttonText }) {
    return (
      <div className="max-w-sm rounded overflow-hidden shadow-lg news_cards_animation">
        <img className="w-full" src={image} alt={altText} />
        <div className="px-6 py-2">
          <div className="font-bold text-xl mb-2">{title}</div>
          <p className="text-gray-700 text-base">{text}</p>
        </div>
        <div className="px-6 pt-4 pb-2">
          <button className="Button_Update">{buttonText}</button>
        </div>
      </div>
    );
  }
  
  export default NewsCard;